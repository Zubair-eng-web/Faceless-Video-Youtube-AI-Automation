# Faceless Video AI

Ek topic (ya sirf niche) se poori short-form video (YouTube Shorts / Reels / TikTok style, 9:16) khud banane wala AI automation system: research, script, voiceover, stock footage, editing, animated captions, thumbnail, SEO, quality check, YouTube publishing, scheduling aur analytics. Control Streamlit dashboard se hota hai.

Halat: Step 14 tak mukammal (neeche "Steps log" aur "Roadmap" dekhein).

---

## 1. Ye project kya karta hai

Aap ek topic dete hain (ya sirf niche, jaise "space facts") aur system:

1. Gemini se topic chunta hai (agar topic na diya ho) aur script + scenes likhta hai
2. Edge TTS se voiceover banata hai, har lafz ke timestamp ke saath
3. Pixabay se har scene ke liye stock clip dhoondta aur download karta hai
4. FFmpeg se video banata hai: 1080x1920 crop, transitions, word-by-word animated captions, aur music (agar di ho)
5. Gemini se title, description, hashtags, tags aur thumbnail text banata hai
6. Pillow se thumbnail banata hai
7. Quality checker se video ki technical jaanch karta hai
8. Video ko dashboard mein review ke liye rakhta hai, aap Approve karte hain
9. Approved video YouTube par upload hoti hai (abhi, schedule se, ya khud)
10. YouTube se views, likes aur comments lekar AI recommendations deta hai

Ek insani step jaan boojh kar rakha gaya hai: **Approve**. Maqsad ye hai ke ghalat facts wali video khud upload na ho.

## 2. Flow
   Gemini key: https://aistudio.google.com/apikey , Pixabay key: https://pixabay.com/api/docs/
4. Check: `python check_env.py` (aakhir mein "Sab theek hai" aana chahiye).

## 7. Kaise chalayen

Har dafa pehle virtual environment active karein: `.\.venv\Scripts\Activate.ps1`

| Kaam | Command |
|---|---|
| Tests | `python -m pytest tests -q` |
| Ek command se poori video | `python -m scripts.make_video "topic"` |
| Niche se topic chuna kar | `python -m scripts.make_video --niche "space facts"` |
| Dusri language / lambai / voice | `--language Spanish --seconds 30 --voice es-ES-AlvaroNeural` |
| API server | `python -m uvicorn app.api.main:create_app --factory --port 8000` |
| Dashboard | `python -m streamlit run dashboard/streamlit_app.py` (http://localhost:8501) |
| API aur dashboard ek saath | `powershell -ExecutionPolicy Bypass -File scripts\run_all.ps1` |
| API docs | http://127.0.0.1:8000/docs |
| YouTube channel connect | `python -m scripts.connect_youtube 1` (1 = database mein channel ki id) |
| Channels ki halat | `python -m scripts.connect_youtube --list` |
| Latest video private upload (test) | `python -m scripts.try_upload` |
| Stats YouTube se lena (test) | `python -m scripts.try_analytics` |
| Production ek baar chalana | `python -m scripts.run_production_once` |

Step-by-step live tests (har hissa alag alag): `scripts.try_script`, `scripts.try_voice`, `scripts.try_clips`, `scripts.try_video`, `scripts.try_finish`.

Video dekhne ke liye browser ya Windows ka default player use karein. VS Code ka built-in preview mp4 ki awaaz nahi chalata.

## 8. API endpoints

| Endpoint | Kaam |
|---|---|
| `GET /health`, `GET /stats` | Server ki halat, videos ki ginti |
| `POST /channels`, `GET /channels`, `GET /channels/{id}`, `DELETE /channels/{id}` | Channels |
| `PUT /channels/{id}/schedule` | Roz kitni videos, kis waqt, kitni lambi |
| `POST /generate` | Video banwana (topic ya niche, optional channel). Background mein chalta hai |
| `GET /videos`, `GET /videos/{id}` | List (status/channel filter) aur tafseel |
| `POST /videos/{id}/approve`, `/reject` | Review |
| `GET /videos/{id}/file`, `/thumbnail` | Video aur thumbnail |
| `POST /videos/{id}/publish` | Abhi YouTube par upload |
| `POST /videos/{id}/schedule`, `/unschedule` | Publish ka waqt lagana ya hatana |
| `POST /videos/{id}/retry-publish` | Fail hui upload dobara |
| `GET /youtube/channels`, `GET /publishing` | Connect ki halat, publishing ki settings |
| `GET /production` | Production schedule aur aaj ki ginti |
| `POST /analytics/refresh`, `GET /analytics`, `POST /analytics/insights` | Stats, summary, AI recommendations |

Video ke statuses: `queued`, `generating`, `ready`, `needs_review`, `approved`, `publishing`, `published`, `publish_failed`, `rejected`, `failed`. "Scheduled" ka matlab hai approved video jis ka `scheduled_at` set ho.

## 9. Dashboard ke pages

- **Videos:** list, filters, player, thumbnail, quality report, SEO (copy ke liye), Approve/Reject, Publish/Schedule. Jo videos ban rahi hon unka progress har 5 second mein update hota hai.
- **Generate:** channel, topic ya niche, language, lambai chun kar video banwana.
- **Channels:** channel banana ya hatana.
- **Production:** har channel ka roz ka schedule (kitni videos, kis waqt se).
- **Analytics:** views, likes, comments, engagement aur AI recommendations.

## 10. YouTube ki setup (ek baar)

1. Google Cloud mein project banayen, aur **YouTube Data API v3** Enable karein.
2. **Google Auth Platform:** Get started mein External chunein. **Data Access** mein scopes `youtube.upload` aur `youtube.readonly` add karein.
3. **Audience** par **Publish app** karein (In production), warna Testing mode mein token 7 din mein expire ho jata hai. Login par "Google hasn't verified this app" aaye to Advanced aur phir Go to ... (unsafe) dabayen, kyunke ye aap ka apna app hai.
4. **Clients** mein **Desktop app** client banayen, JSON download karke project folder mein `client_secret.json` naam se rakhein. (Windows mein file ka extension chhupa ho to naam `client_secret.json.json` ban sakta hai.)
5. `python -m scripts.connect_youtube <channel id>` chalayen, browser mein login karke permissions allow karein.

**Zaroori limits (YouTube ke official docs ke mutabiq):**
- Naye API projects (28 July 2020 ke baad) jab tak Google ka compliance audit pass na karein, unki upload ki hui videos **private** lock ho jati hain. Audit ka form free hai, lekin app chalta hua dikhana parta hai.
- Ek upload 1600 quota units leta hai aur roz 10,000 units milte hain, yani lagbhag 6 uploads. Asli limit Cloud Console ke Quotas page par dekhein.
- Analytics ke liye `youtube.readonly` permission chahiye. Purana token ho to channel dobara connect karein.
- Custom thumbnail ke liye YouTube channel ka verify hona zaroori ho sakta hai. Thumbnail fail ho to upload fail nahi hoti.

## 11. Settings (`.env`)

| Setting | Default | Matlab |
|---|---|---|
| `GEMINI_API_KEY`, `PIXABAY_API_KEY` | | Zaroori keys |
| `GEMINI_MODEL` | `gemini-3.1-flash-lite` | Gemini ka model |
| `AUTO_PUBLISH` | `false` | `true` ho to schedule wali approved videos khud upload hon |
| `DEFAULT_PRIVACY` | `private` | `private`, `unlisted` ya `public`. Public sirf audit ke baad kaam karega |
| `DAILY_UPLOAD_LIMIT` | `5` | Roz zyada se zyada kitni uploads |
| `PUBLISH_CHECK_MINUTES` | `5` | Scheduler kitne minute baad publish check kare |
| `AUTO_PRODUCE` | `false` | `true` ho to channels ke schedule ke mutabiq videos khud banen |
| `PRODUCE_CHECK_MINUTES` | `10` | Scheduler kitne minute baad production check kare |

Auto production se bani videos `ready` ya `needs_review` mein aati hain. Publish se pehle Approve zaroori hai.

Voices (Edge TTS): English `en-US-AndrewNeural`, Hindi `hi-IN-MadhurNeural`, Urdu `ur-PK-AsadNeural`, Spanish `es-ES-AlvaroNeural`, French `fr-FR-HenriNeural`, Arabic `ar-SA-HamedNeural`.

## 12. Tests

`python -m pytest tests -q`. Step 13 par 285 tests hone chahiye. Tests mein Gemini, Pixabay, Edge TTS aur YouTube sab fake hain, is liye internet ya keys ke baghair chalte hain. `httpx2` wali warning FastAPI ke test tool ki hai, nuksaan nahi karti.

## 13. Security

- `.env`, `client_secret.json` aur `data/tokens/` kisi ko share na karein aur git mein na dalein (`.gitignore` mein hain).
- Agar koi key ya secret chat ya screenshot mein share ho jaye, to Google Cloud ya AI Studio mein naya bana kar purana band kar dein.
- Dashboard aur API sirf is computer par (localhost) chalte hain, aur in mein login nahi hai. Internet par kholne se pehle login lagana zaroori hai.

## 14. Steps log (jo mukammal ho chuka)

### Step 1: Environment
- Virtual environment, `requirements.txt`, `.env` aur `.gitignore`, FFmpeg ki jaanch, `check_env.py`.
- Pexels ki jagah Pixabay chuna gaya.

### Step 2: Folder structure aur config
- Poora folder structure, `app/core/config.py` (pydantic-settings), `pytest.ini`. 5 tests.

### Step 3: Gemini (research, script, storyboard)
- `gemini_client.py`: JSON schema ke saath jawab, temporary errors par retry, galat key ya model par fauran saaf error.
- `research_agent.py`, `script_agent.py`, `models.py`, `storyboard.py`. Live test: `scripts/try_script.py`. Total 21 tests.

### Step 4: Voiceover aur word timestamps
- `tts.py`: har scene ki mp3, `ffprobe` se asli duration, WordBoundary se word timings (na milen to andaza), 6 zabanon ki voices, `apply_durations`. Live test: `scripts/try_voice.py`. Total 31 tests.

### Step 5: Pixabay se stock video
- `pixabay.py`: search 24 ghante cache, behtareen clip ka chunav (portrait ko tarjih, 1080 quality, koi clip repeat nahi), query fail ho to chhoti query phir title, download cache.
- Script prompt sakht kiya: hook 12 lafz se kam, kul lambai "at most". Live test: `scripts/try_clips.py`. Total 51 tests.

### Step 6: FFmpeg editing aur animated captions
- `captions.py` (ASS, word highlight) aur `video_editor.py` (9:16 crop, xfade transitions, voiceover, optional music, Arial font copy). Live test: `scripts/try_video.py`. Total 70 tests.

### Step 7: SEO, thumbnail aur quality checker
- `seo_agent.py` (title 100 chars se kam, `#Shorts` pehle, tags 500 chars se kam), `thumbnail.py` (1080x1920 JPEG, 2 MB se kam), `quality.py` (resolution, audio, duration, black frames, khamoshi, awaaz ki level, captions, clips). Live test: `scripts/try_finish.py`. Total 105 tests.

### Step 8: Poori pipeline ek command mein
- `pipeline.py`: 7 steps, har fail hone wale step ka naam, `result.json`, status `ready` ya `needs_review`. `scripts/make_video.py`. Total 114 tests.

### Step 9: Database aur FastAPI
- `db.py` (channels, videos, migrations), `api/main.py`, `runner.py`, `schemas.py`. Jobs background mein, ek waqt mein ek. Adhoori jobs server restart par `failed` mark hoti hain. Total 148 tests.

### Step 10: Streamlit dashboard
- Pages Videos, Generate, Channels. `api_client.py`, `helpers.py`, `scripts/run_all.ps1`. Total 168 tests.

### Step 11: YouTube se connect aur upload
- `youtube.py`: har channel ka alag token (`data/tokens/`), token khud refresh, resumable upload, thumbnail upload, quota aur login ke alag errors. `scripts/connect_youtube.py` aur `scripts/try_upload.py`. Pehli private upload kamyab. Total 188 tests.

### Step 12: Publish, schedule aur auto publish
- `db_publish.py`, `publisher.py`, `scheduler.py`, `publish_routes.py`. Dashboard mein "Abhi publish", "Schedule", "Dobara koshish".
- Roz ki upload limit, quota khatam ho to 1 ghanta ruk jana, server band hone par adhoori upload `publish_failed` (taake video do dafa upload na ho). `AUTO_PUBLISH` default band. Total 237 tests.

### Step 13: Auto production aur analytics
- Production schedule: har channel ke liye roz 0 se 5 videos, waqt, lambai (`db_production.py`, `production.py`). Roz 2 fail hone par channel us din ke liye ruk jata hai. `AUTO_PRODUCE` default band.
- Analytics: `youtube_stats.py` (views, likes, comments), `analytics.py`, `insights_agent.py` (Gemini se recommendations, kam az kam 3 videos ke stats chahiye).
- Dashboard pages Production aur Analytics. Naya scope `youtube.readonly`. `scripts/run_production_once.py` aur `scripts/try_analytics.py`. Total 285 tests.

<!-- STEPS-LOG-END -->

## 15. Roadmap (baqi kaam)

**Step 14 ke liye tin options (aap chunein ke pehle kaunsa):**

| Option | Kaam | Feature # |
|---|---|---|
| A | Multilingual captions: Hindi, Urdu, Arabic ke fonts (Noto), sahi shaping aur right-to-left ki jaanch, non-English videos ke test | 7, 12 |
| B | Background music: mood ke hisab se khud track chunna, voiceover ke waqt music halki, transitions par sound effects | 8 |
| C | Multiple variations: ek topic se kai hooks aur scripts, har ka alag video, aur behtareen ka chunav | 10 |

**Uske baad ke kaam:**

| Kaam | Tafseel | Feature # |
|---|---|---|
| Fact-check step | Script ke dawon ki dobara jaanch (Gemini ka doosra pass), taake ghalat facts kam hon | 11 |
| Behtar trend research | YouTube ya Google Trends ke asli data se topics | 1 |
| Channel branding | Har channel ke captions ke rang aur font, logo watermark, intro/outro | 16 |
| Dusre platforms | Instagram Reels, TikTok (unke API ki shartein dekh kar, warna export folder) | 13 |
| YouTube audit | Compliance audit pass karna taake videos public upload ho saken | 13 |
| Quality checker v2 | AI se check ke clip scene se match karti hai ya nahi, captions parhne mein aate hain ya nahi | 11 |
| Dashboard behtari | Render se pehle script edit karna, kisi ek scene ki clip badalna, fail hue step se dobara chalana | |
| Deployment | Windows Task Scheduler ya Docker mein chalana, database ka backup, logs | |
| Security | Agar internet par kholna ho to API aur dashboard par login | |

## 16. Maloom masle aur limits

- Videos abhi sirf private upload hoti hain (audit se pehle), aur is hisaab se analytics ke numbers bohat kam honge.
- Topics Gemini ke general knowledge se aate hain, live trends se nahi. Gemini kabhi kabhi ghalat facts likh deta hai, is liye Approve se pehle facts khud dekhein.
- Hindi, Urdu aur Arabic ke captions ka font abhi nahi lagaya (Arial mein ye huroof nahi hote). English theek hai.
- Music folder (`assets/music`) shuru mein khali hai. Koi royalty-free mp3 ya wav rakhein, license check kar ke.
- Gemini aur Pixabay ki free limits hain, is liye videos ek ek kar ke banti hain. 429 error aaye to thori der baad dobara try karein.
- Pixabay ki shart ke mutabiq search results 24 ghante se zyada cache nahi kiye jate.
- Windows mein file ka extension chhupa ho to download ki hui JSON ka naam `.json.json` ban sakta hai. File Explorer mein View > Show > File name extensions on kar lein.

## 17. Is README ko kaise update karte hain

Har naya step mukammal hone par:
1. "Steps log" mein us step ki entry (kya bana, kaun si files, kitne tests) `STEPS-LOG-END` ke marker se pehle jorti jati hai.
2. "Features ki halat" ki table aur "Roadmap" ki halat badli jati hai.
3. Naye commands, settings ya endpoints ho to unki tables mein jorte jate hain.

## Folder structure

```text
YouTube_AI_Automation/
├── .streamlit/
│   └── config.toml
├── app/
│   ├── agents/
│   │   ├── insights_agent.py
│   │   ├── research_agent.py
│   │   ├── script_agent.py
│   │   ├── seo_agent.py
│   │   └── __init__.py
│   ├── api/
│   │   ├── main.py
│   │   ├── production_routes.py
│   │   ├── publish_routes.py
│   │   ├── runner.py
│   │   ├── schemas.py
│   │   ├── variation_routes.py
│   │   └── __init__.py
│   ├── core/
│   │   ├── analytics.py
│   │   ├── config.py
│   │   ├── db.py
│   │   ├── db_production.py
│   │   ├── db_publish.py
│   │   ├── models.py
│   │   ├── storyboard.py
│   │   └── __init__.py
│   ├── services/
│   │   ├── background.py
│   │   ├── captions.py
│   │   ├── fonts.py
│   │   ├── gemini_client.py
│   │   ├── pixabay.py
│   │   ├── production.py
│   │   ├── publisher.py
│   │   ├── quality.py
│   │   ├── scheduler.py
│   │   ├── thumbnail.py
│   │   ├── thumbnail_ass.py
│   │   ├── tts.py
│   │   ├── variations.py
│   │   ├── video_editor.py
│   │   ├── youtube.py
│   │   ├── youtube_stats.py
│   │   └── __init__.py
│   ├── pipeline.py
│   └── __init__.py
├── assets/
│   ├── cache/
│   │   ├── clips/
│   │   └── pixabay_search/
│   ├── fonts/
│   │   ├── FONTS.txt
│   │   ├── arial.ttf
│   │   ├── arialbd.ttf
│   │   ├── NotoNaskhArabic-Bold.ttf
│   │   └── NotoSansDevanagari-Bold.ttf
│   └── music/
├── dashboard/
│   ├── api_client.py
│   ├── helpers.py
│   ├── ops_helpers.py
│   ├── streamlit_app.py
│   └── __init__.py
├── data/
│   ├── tokens/
│   └── app.db
├── output/
│   ├── clips_test/
│   ├── fonts_test/
│   ├── multilingual_test/
│   ├── runs/
│   ├── video_test/
│   ├── voice_test/
│   └── last_storyboard.json
├── scripts/
│   ├── check_fonts.py
│   ├── connect_youtube.py
│   ├── diagnose_production.py
│   ├── diagnose_run.py
│   ├── make_video.py
│   ├── patch_test.py
│   ├── readme_update.py
│   ├── run_all.ps1
│   ├── run_production_once.py
│   ├── set_schedule_now.py
│   ├── set_schedule_one.py
│   ├── status.py
│   ├── try_analytics.py
│   ├── try_clips.py
│   ├── try_finish.py
│   ├── try_multilingual.py
│   ├── try_script.py
│   ├── try_upload.py
│   ├── try_video.py
│   ├── try_voice.py
│   └── __init__.py
├── tests/
│   ├── test_agents.py
│   ├── test_analytics_insights.py
│   ├── test_api.py
│   ├── test_background.py
│   ├── test_captions.py
│   ├── test_captions_multilingual.py
│   ├── test_config.py
│   ├── test_dashboard_api_client.py
│   ├── test_dashboard_app.py
│   ├── test_dashboard_helpers.py
│   ├── test_dashboard_ops.py
│   ├── test_dashboard_publish.py
│   ├── test_dashboard_variations.py
│   ├── test_db.py
│   ├── test_db_production.py
│   ├── test_db_publish.py
│   ├── test_fonts.py
│   ├── test_gemini_client.py
│   ├── test_multilingual_script.py
│   ├── test_multilingual_seo.py
│   ├── test_pipeline.py
│   ├── test_pixabay.py
│   ├── test_production.py
│   ├── test_production_api.py
│   ├── test_publisher.py
│   ├── test_publish_api.py
│   ├── test_quality.py
│   ├── test_readme_update.py
│   ├── test_scheduler.py
│   ├── test_seo.py
│   ├── test_storyboard.py
│   ├── test_thumbnail.py
│   ├── test_thumbnail_complex.py
│   ├── test_tts.py
│   ├── test_variations.py
│   ├── test_video_editor.py
│   ├── test_voice_and_clip_fixes.py
│   ├── test_youtube.py
│   └── test_youtube_stats.py
├── .pytest_cache/
├── .venv/
├── .env
├── .env.example
├── .gitignore
├── README.bak.md
├── README.md
├── check_env.py
├── client_secret.json
├── client_secret.json.json
├── pytest.ini
└── requirements.txt
```

`assets/cache/`, `data/tokens/` aur `output/` ke andar cache, local tokens aur generated test/run files hain; `.venv/` aur `.pytest_cache/` mein local environment aur test cache hai.
