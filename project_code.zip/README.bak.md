# YouTube AI Automation

This project automates a faceless YouTube video workflow using AI agents, pipeline steps, and local media generation tools.

## Project structure

```text
YouTube_AI_Automation/
├── README.md
├── requirements.txt
├── pytest.ini
├── check_env.py
├── client_secret.json
├── client_secret.json.json
│
├── app/
│   ├── __init__.py
│   ├── pipeline.py
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── insights_agent.py
│   │   ├── research_agent.py
│   │   ├── script_agent.py
│   │   └── seo_agent.py
│   ├── api/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── production_routes.py
│   │   ├── publish_routes.py
│   │   ├── runner.py
│   │   └── schemas.py
│   ├── core/
│   │   ├── __init__.py
│   │   ├── analytics.py
│   │   ├── config.py
│   │   ├── db.py
│   │   ├── db_production.py
│   │   ├── db_publish.py
│   │   └── models.py
│   └── services/
│       ├── __init__.py
│       ├── background.py
│       ├── captions.py
│       ├── gemini_client.py
│       ├── pixabay.py
│       ├── production.py
│       ├── publisher.py
│       ├── quality.py
│       ├── scheduler.py
│       ├── thumbnail.py
│       ├── tts.py
│       ├── video_editor.py
│       ├── youtube.py
│       └── youtube_stats.py
│
├── dashboard/
│   ├── __init__.py
│   ├── api_client.py
│   ├── helpers.py
│   ├── ops_helpers.py
│   └── streamlit_app.py
│
├── data/
│   ├── app.db
│   └── tokens/
│       └── youtube_1.json
│
├── output/
│   ├── last_storyboard.json
│   ├── clips_test/
│   ├── runs/
│   ├── video_test/
│   └── voice_test/
│
├── assets/
│   ├── cache/
│   ├── fonts/
│   └── music/
│
├── scripts/
│   ├── __init__.py
│   ├── connect_youtube.py
│   ├── make_video.py
│   ├── run_all.ps1
│   ├── try_analytics.py
│   ├── try_clips.py
│   ├── try_finish.py
│   ├── try_script.py
│   ├── try_upload.py
│   ├── try_video.py
│   └── try_voice.py
│
├── tests/
│   ├── test_agents.py
│   ├── test_analytics_insights.py
│   ├── test_api.py
│   ├── test_background.py
│   ├── test_captions.py
│   ├── test_config.py
│   ├── test_dashboard_api_client.py
│   ├── test_dashboard_app.py
│   ├── test_dashboard_helpers.py
│   ├── test_dashboard_ops.py
│   ├── test_db.py
│   ├── test_db_production.py
│   ├── test_db_publish.py
│   ├── test_gemini_client.py
│   ├── test_pipeline.py
│   ├── test_pixabay.py
│   ├── test_production.py
│   ├── test_production_api.py
│   ├── test_publish_api.py
│   ├── test_publisher.py
│   ├── test_quality.py
│   ├── test_scheduler.py
│   ├── test_seo.py
│   ├── test_storyboard.py
│   ├── test_thumbnail.py
│   ├── test_tts.py
│   ├── test_video_editor.py
│   ├── test_youtube.py
│   └── test_youtube_stats.py
│
└── .venv/   (local environment, not committed)
```

- `app/` — main application logic
- `dashboard/` — Streamlit dashboard UI
- `scripts/` — helper scripts for running tasks manually
- `tests/` — unit and API tests
- `data/` — database and tokens
- `output/` — generated videos, captions, storyboard, and run folders
- `assets/` — fonts, music, and cached media

## Prerequisites

- Python 3.11+
- Windows PowerShell
- FFmpeg installed and available on PATH
- Access to Gemini / AI services configured in the app settings
- Required Python packages from `requirements.txt`

## Setup in PowerShell

```powershell
cd e:\YouTube_AI_Automation
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## Run tests

```powershell
cd e:\YouTube_AI_Automation
.\.venv\Scripts\Activate.ps1
python -m pytest tests -q
```

## Run scripts

```powershell
cd e:\YouTube_AI_Automation
.\.venv\Scripts\Activate.ps1
python scripts\try_script.py
```

## Common commands

```powershell
cd e:\YouTube_AI_Automation
.\.venv\Scripts\Activate.ps1
python --version
```

## Notes

- Keep the virtual environment in the project root as `.venv`.
- If PowerShell blocks script execution, run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

- For local development, always activate the venv before running Python commands.
